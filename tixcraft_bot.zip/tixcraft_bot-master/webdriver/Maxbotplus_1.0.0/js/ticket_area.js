// price row.
$("ul.area-list > span > li:not(:has(a))").remove();
// description row.
$("ul.area-list > li:not(:has(a))").remove();
$("footer").remove();