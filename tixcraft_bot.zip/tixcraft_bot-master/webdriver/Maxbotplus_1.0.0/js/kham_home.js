$("div#dialog-message").remove();
$("div#ad3").remove();
$("div#buyTicket").remove();
$("div#marquee").remove();
$("div.footer").remove();
$(".popoutBG").remove();
