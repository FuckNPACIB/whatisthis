$("div.headlines").remove();
$("section.app-intro").remove();
$("section.copywriting").remove();
$("section.partner-venues").remove();
$("footer").remove();
